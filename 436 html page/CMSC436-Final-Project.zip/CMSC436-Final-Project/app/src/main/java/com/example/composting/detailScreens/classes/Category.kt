package com.example.composting.detailScreens.classes

class Category {
    companion object {
        val CATEGORY_FOOD: Int = 1
        val CATEGORY_VEG: Int = 2
        val CATEGORY_LIVE: Int = 3
    }
}