package com.example.composting.leaderboardScreens

class Person (em : String, sc : Int) {
    val email: String = em
    val score: Int = sc
}