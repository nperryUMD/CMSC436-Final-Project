package com.example.composting.detailScreens.classes

data class CompostItems(
    var name: String,
    var category: Int,
    var health: Int
)

